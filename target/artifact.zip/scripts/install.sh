#!/bin/bash
sudo yum -y install tomcat
sudo yum -y install httpd